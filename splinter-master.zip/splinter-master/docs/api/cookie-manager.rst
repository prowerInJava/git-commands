.. Copyright 2012 splinter authors. All rights reserved.
   Use of this source code is governed by a BSD-style
   license that can be found in the LICENSE file.

.. meta::
    :description: Splinter cookies API documentation
    :keywords: splinter, python, api documentation, cookies, cookies manipulation

CookieManager
=============

.. module:: splinter.cookie_manager

.. autoclass:: CookieManagerAPI
   :members:
