.. Copyright 2012 splinter authors. All rights reserved.
   Use of this source code is governed by a BSD-style
   license that can be found in the LICENSE file.

.. meta::
    :description: Splinter API documentation for ElementList
    :keywords: splinter, python, api documentation, api, DOM manipulation, element list

ElementList
===========

.. module:: splinter.element_list

.. autoclass:: ElementList
   :show-inheritance:
   :members:
